#pragma once

#define __NST_API __declspec(dllimport)
#define NST_API_EXTERN extern "C" __NST_API

enum class EIndexType : unsigned char
{
	AllStatesArray = 0,
	AvailabilityArray = 1
};

enum class EDelegateType : unsigned char
{
	OnAvailableStatesChanged = 0,
	OnStateActivated = 1,
	OnReset = 2,
	OnStateAvailabilityChanged = 3,
	OnPropertyValueChanged = 4
};

/*!@brief Creates a new NST World. Remember to always call NST_DeleteWorld to avoid a memory leak.
 *
 * @returns Either a 32-bit or a 64-bit handle (memory location) of the newly created World.
 */
NST_API_EXTERN size_t NST_CreateNewWorld();

/*!@brief Deletes the provided NST World.
 *
 * @param handle The handle of the NST World to delete. This handle must be prevously created by NST_CreateNewWorld.
 */
NST_API_EXTERN void NST_DeleteWorld(size_t handle);

/*!@brief Gets the number of all states.
 *
 * @param handle The handle of the NST World.
 * @returns The number of states.
 */
NST_API_EXTERN size_t NST_GetNumStates(size_t handle);

/*!@brief Gets the number of currently available states.
 *
 * @param handle The handle of the NST World.
 * @returns The number of available states.
 */
NST_API_EXTERN size_t NST_GetNumAvailableStates(size_t handle);

/*!@brief Gets the name of the state at the given index. Usually used in combination with NST_GetNumAvailableStates.
 *
 * @param handle The handle of the NST World.
 * @param indexType What's the context of this index. See the EIndexType
*  enum or use 0 for all states and 1 for available states.
 * @param index The index at which to get the state name.
 * @returns The name of the state at the given index, no whitespaces.
 */
NST_API_EXTERN const char* NST_GetStateNameAtIndex(size_t handle, unsigned char indexType, size_t index);

/*!@brief Gets the availablilty of a state with a given state name.
 *
 * @param handle The handle of the NST World.
 * @param stateName The name of the state which is the context of this check.
 * @returns True if the state is available, false if the state is not available or there is an error.
 */
NST_API_EXTERN bool NST_IsStateAvailable(size_t handle, const char* stateName);

/*!@brief Gets the dialog statement (named choice) for the provided state name.
 *
 * @param handle The handle of the NST World.
 * @param index The name of the state for which to return the actual dialog statement.
 * @returns The dialog statement string.
 */
NST_API_EXTERN const char* NST_GetDialogStatement(size_t handle, const char* stateName);

/*!@brief Gets the situation string in the currently active state.
 *
 * @param handle The handle of the NST World.
 * @returns The situation string of the active state.
 */
NST_API_EXTERN const char* NST_GetActiveStateSituation(size_t handle);

/*!@brief Gets the property value for the given property name.
 *
 * @param handle The handle of the NST World.
 * @param propertyName The name of the property for which to get the value.
 * @returns Tha value of the provided property name.
 */
NST_API_EXTERN float NST_GetPropertyValue(size_t handle, const char* propertyName);

/*!@brief Sets the property value for the given property name.
 *
 * @param handle The handle of the NST World.
 * @param propertyName The name of the property for which to set the value.
 * @param propertyValue The value of the property to set.
 */
NST_API_EXTERN void NST_SetPropertyValue(size_t handle, const char* propertyName, float propertyValue);

/*!@brief Activate the state with the given name. If the state is not available the state will not be activated.
 *
 * @param handle The handle of the NST World.
 * @param stateName The name of the state.
 */
NST_API_EXTERN void NST_ActivateState(size_t handle, const char* stateName);

/*!@brief Activate the state with the given name. The state will be activated regardless of its evaluation.
 *
 * @param handle The handle of the NST World.
 * @param stateName The name of the state.
 */
NST_API_EXTERN void NST_ForceActivateState(size_t handle, const char* stateName);

/*!@brief Resets the story with a new seed.
 *
 * @param handle The handle of the NST World.
 */
NST_API_EXTERN void NST_ResetStory(size_t handle);

/*!@brief Binds a function to a delegate defined in the enum EDelegateType.
 *
 * @param handle The handle of the NST World.
 * @param stdFunctionPtr A pointer to a std::function<T> instance (or equivalent).
 * @param delegateType as defined by the enum EDelegateType.
 */
NST_API_EXTERN void NST_DelegateBindFunction(size_t handle, size_t stdFunctionPtr, unsigned char delegateType);

/*!@brief Attempts to load a story from the provided string.
 *
 * @param handle The handle of the NST World.
 * @param str The string loaded from a .nss file or generated via some other method.
 */
NST_API_EXTERN void NST_LoadFromString(size_t handle, const char* str);

/*!@brief Gets the current string for the story. This includes the currently active branch and currently active state.
 *
 * @param handle The handle of the NST World.
 * @returns Returns the story string, base64 encoded and encrypted
 */
NST_API_EXTERN const char* NST_GetCurrentStoryString(size_t handle);