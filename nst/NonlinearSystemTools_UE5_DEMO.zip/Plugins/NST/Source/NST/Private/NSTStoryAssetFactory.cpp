// � 2022 Martin Petkovski. All rights reserved.
#include "NSTStoryAssetFactory.h"
#include "NSTStoryAsset.h"
#include "Misc/FileHelper.h" 

UNSTStoryAssetFactory::UNSTStoryAssetFactory(const class FObjectInitializer& OBJ) 
    : Super(OBJ) 
{
    SupportedClass = UNSTStoryAsset::StaticClass();

    bCreateNew = false;
    bEditAfterNew = false;
    bEditorImport = true;   // binary / general file source
    bText = false;  // text source

    Formats.Add(TEXT("nss;Nonlinear System Story"));
}

UObject* UNSTStoryAssetFactory::FactoryCreateFile(
    UClass* InClass, UObject* InParent, FName InName, EObjectFlags Flags, const FString& Filename,
    const TCHAR* Parms, FFeedbackContext* Warn, bool& bOutOperationCanceled)
{
    GEditor->GetEditorSubsystem<UImportSubsystem>()->BroadcastAssetPreImport(this, InClass, InParent, InName, Parms);

    UNSTStoryAsset* storyAsset = nullptr;
    FString TextString;
    if (FFileHelper::LoadFileToString(TextString, *CurrentFilename))
    {
        storyAsset = NewObject<UNSTStoryAsset>(InParent, InClass, InName, Flags);
        storyAsset->StoryContent = TextString;
    }

    return storyAsset;
}

bool UNSTStoryAssetFactory::FactoryCanImport(const FString& Filename)
{
    const FString Extension = FPaths::GetExtension(Filename);

    if (Extension == TEXT("nss"))
    {
        return true;
    }
    return false;
}