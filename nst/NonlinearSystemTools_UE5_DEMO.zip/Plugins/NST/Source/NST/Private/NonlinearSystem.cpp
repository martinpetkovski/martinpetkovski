// � 2022 Martin Petkovski. All rights reserved.
#include "NonlinearSystem.h"
#include "NSTAPI.h"
#include <functional>

ANonlinearSystem::ANonlinearSystem()
{
	PrimaryActorTick.bCanEverTick = true;
	mWorld = NST_CreateNewWorld();
}

ANonlinearSystem::~ANonlinearSystem()
{
	NST_DeleteWorld(mWorld);
}

FString ANonlinearSystem::GetSituation()
{
	return FString(NST_GetActiveStateSituation(mWorld));
}

int32 ANonlinearSystem::GetNumStates()
{
	return NST_GetNumStates(mWorld);
}

int32 ANonlinearSystem::GetNumAvailableStates()
{
	return NST_GetNumAvailableStates(mWorld);
}

FString ANonlinearSystem::GetDialogStatement(FString stateName)
{
	const char* statement = NST_GetDialogStatement(mWorld, ToStdString(stateName).c_str());
	return FString(statement);
}

FString ANonlinearSystem::GetStateNameAtIndex(int32 index)
{
	return NST_GetStateNameAtIndex(mWorld, 1, index);
}

bool ANonlinearSystem::IsStateAvailable(FString stateName)
{
	return NST_IsStateAvailable(mWorld, ToStdString(stateName).c_str());
}

void ANonlinearSystem::ActivateState(FString stateName, bool force)
{
	if (force)
	{
		NST_ForceActivateState(mWorld, ToStdString(stateName).c_str());
	}
	else
	{
		NST_ActivateState(mWorld, ToStdString(stateName).c_str());
	}
}

void ANonlinearSystem::ResetStory()
{
	NST_ResetStory(mWorld);
}

void ANonlinearSystem::SaveStory()
{
	const char* storyStr = NST_GetCurrentStoryString(mWorld);
	if (storyStr)
	{
		CurrentStoryString = storyStr;
	}
}

void ANonlinearSystem::LoadFromString(FString storyString)
{
	NST_LoadFromString(mWorld, ToStdString(storyString).c_str());
}

float ANonlinearSystem::GetPropertyValue(FString propertyName)
{
	return NST_GetPropertyValue(mWorld, ToStdString(propertyName).c_str());
}

void ANonlinearSystem::SetPropertyValue(FString propertyName, float value)
{
	return NST_SetPropertyValue(mWorld, ToStdString(propertyName).c_str(), value);
}

void ANonlinearSystem::BeginPlay()
{
	Super::BeginPlay();

	if (!Story->StoryContent.IsEmpty())
	{
		std::string str = ToStdString(*Story->StoryContent);
		const char* c = str.c_str();
		NST_LoadFromString(mWorld, c);
	}

	NST_INITIALIZE_DELEGATE(AvailableStatesChanged);
	NST_INITIALIZE_DELEGATE_TYPED(const char*, StateActivated);
	NST_INITIALIZE_DELEGATE(Reset);
	NST_INITIALIZE_DELEGATE_TYPED(const char*, StateAvailabilityChanged);
	NST_INITIALIZE_DELEGATE_TYPED(const char*, PropertyValueChanged);
}

void ANonlinearSystem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

