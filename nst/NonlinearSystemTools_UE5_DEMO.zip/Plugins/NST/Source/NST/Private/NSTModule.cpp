// � 2022 Martin Petkovski. All rights reserved.
#include "NSTModule.h"
#include "Interfaces/IPluginManager.h"
#include "AssetToolsModule.h" 

#include "NSTStoryAssetFactory.h"
#include "NSTStoryAssetActions.h"
#include "NSTAPI.h"

#define LOCTEXT_NAMESPACE "FNSTModule"

void FNSTModule::StartupModule()
{
	IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	MY_AssetCategory = AssetTools.RegisterAdvancedAssetCategory(FName(TEXT("NST")), LOCTEXT("NST", "NST"));
	{
		TSharedRef<IAssetTypeActions> ACT_UMyItemsDatabase = MakeShareable(new FNSTStoryAssetActions);
		AssetTools.RegisterAssetTypeActions(ACT_UMyItemsDatabase);
	}

	FString BaseDir = IPluginManager::Get().FindPlugin("NST")->GetBaseDir();

	FString LibraryPath;
#if PLATFORM_WINDOWS
	LibraryPath = FPaths::Combine(*BaseDir, TEXT("Binaries/Win64/NSTAPI.dll"));
#endif // PLATFORM_WINDOWS
	LibraryHandle = !LibraryPath.IsEmpty() ? FPlatformProcess::GetDllHandle(*LibraryPath) : nullptr;

	if (!LibraryHandle)
	{
		FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("NST Plugin", "Failed to load the NST Plugin"));
	}
}

void FNSTModule::ShutdownModule()
{
	FPlatformProcess::FreeDllHandle(LibraryHandle);
	LibraryHandle = nullptr;
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FNSTModule, NST)
