// � 2022 Martin Petkovski. All rights reserved.
using UnrealBuildTool;

public class NST : ModuleRules
{
	public NST(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		
		PublicIncludePaths.AddRange(
			new string[] { }
			);
				
		
		PrivateIncludePaths.AddRange(
			new string[] { }
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"CoreUObject", 
				"Engine",
				"SlateCore",
				"Slate",
				"UnrealEd",
				"Projects",
				"NSTAPI"
			}
			);
			
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{ }
			);
		
		
		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{ }
			);

	}
}
