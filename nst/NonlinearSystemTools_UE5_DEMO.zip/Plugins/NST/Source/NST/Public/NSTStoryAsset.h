// � 2022 Martin Petkovski. All rights reserved.
#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "NSTStoryAsset.generated.h"

UCLASS(ClassGroup = NST, Category = "NST", BlueprintType, Blueprintable)
class NST_API UNSTStoryAsset : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY()
	FString StoryContent;
};
