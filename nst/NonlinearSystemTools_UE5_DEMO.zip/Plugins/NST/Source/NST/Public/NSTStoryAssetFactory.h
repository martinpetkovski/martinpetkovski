#pragma once
// � 2022 Martin Petkovski. All rights reserved.
#include "CoreMinimal.h"
#include "Factories/Factory.h"
#include "AssetTypeCategories.h" 
#include "NSTStoryAssetFactory.generated.h"


static EAssetTypeCategories::Type MY_AssetCategory;

UCLASS()
class NST_API UNSTStoryAssetFactory : public UFactory
{
	GENERATED_UCLASS_BODY()
public:
	virtual UObject* FactoryCreateFile(UClass* InClass, UObject* InParent, FName InName, EObjectFlags Flags, const FString& Filename,
		const TCHAR* Parms, FFeedbackContext* Warn, bool& bOutOperationCanceled) override;
	bool FactoryCanImport(const FString& Filename) override;
};
