// � 2022 Martin Petkovski. All rights reserved.
#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "AssetTypeActions_Base.h" 
#include "NSTStoryAsset.h"

#define LOCTEXT_NAMESPACE "StoryAsset"

class NST_API FNSTStoryAssetActions : public FAssetTypeActions_Base
{
public:
    virtual FText GetName() const override { return LOCTEXT("FNSTStoryAssetActions", "Nonlinear System Story"); }
    virtual uint32 GetCategories() override { return EAssetTypeCategories::Gameplay; }
    virtual FColor GetTypeColor() const override { return FColor(9, 184, 212); }
    virtual FText GetAssetDescription(const FAssetData& AssetData) const override { return LOCTEXT("FNSTStoryAssetActionsDescription", "Nonlinear System Story asset"); }
    virtual UClass* GetSupportedClass() const override { return UNSTStoryAsset::StaticClass(); }
};
#undef LOCTEXT_NAMESPACE