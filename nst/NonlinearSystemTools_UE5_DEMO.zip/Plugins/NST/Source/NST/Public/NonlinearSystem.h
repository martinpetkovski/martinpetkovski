// � 2022 Martin Petkovski. All rights reserved.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "NSTStoryAsset.h"

#include <string>

#include "NonlinearSystem.generated.h"

#define NST_DECLARE_DELEGATE(name)  void name() { On##name.Broadcast(); }
#define NST_DECLARE_DELEGATE_TYPED(typeIn, typeBroadcast, name) void name(typeIn out) { On##name.Broadcast(typeBroadcast(out)); }
#define NST_INITIALIZE_DELEGATE(name) std::function<void()> fn##name = std::bind(&ANonlinearSystem::##name, this); NST_DelegateBindFunction(mWorld, (uint64)&fn##name, (unsigned char)EDelegateType::On##name);
#define NST_INITIALIZE_DELEGATE_TYPED(type, name) std::function<void(type)> fn##name = std::bind(&ANonlinearSystem::##name, this, std::placeholders::_1); NST_DelegateBindFunction(mWorld, (uint64)&fn##name, (unsigned char)EDelegateType::On##name);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnAvailableStatesChanged);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnStateActivated, FString, ActivatedStateName);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnReset);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnStateAvailabilityChanged, FString, StateName);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnPropertyValueChanged, FString, PropertyName);

UCLASS()
class NST_API ANonlinearSystem : public AActor
{
	GENERATED_BODY()
		NST_DECLARE_DELEGATE(AvailableStatesChanged)
		NST_DECLARE_DELEGATE_TYPED(const char*, FString, StateActivated)
		NST_DECLARE_DELEGATE(Reset)
		NST_DECLARE_DELEGATE_TYPED(const char*, FString, StateAvailabilityChanged)
		NST_DECLARE_DELEGATE_TYPED(const char*, FString, PropertyValueChanged)

private:
	size_t mWorld;

	// all story strings are base64 encoded, no need for wide chars
	std::string ToStdString(FString string)
	{
		std::string retVal;
		retVal.resize(string.Len());

		size_t i = 0;
		for (wchar_t c : string.GetCharArray())
		{
			retVal[i] = c;
			i++;
		}

		return retVal;
	};

	UPROPERTY()
		FString CurrentStoryString;

public:
	ANonlinearSystem();
	~ANonlinearSystem();

	UPROPERTY(BlueprintAssignable, Category="Nonlinear System Tools")
		FOnAvailableStatesChanged OnAvailableStatesChanged;

	UPROPERTY(BlueprintAssignable, Category = "Nonlinear System Tools")
		FOnStateActivated OnStateActivated;

	UPROPERTY(BlueprintAssignable, Category = "Nonlinear System Tools")
		FOnReset OnReset;

	UPROPERTY(BlueprintAssignable, Category = "Nonlinear System Tools")
		FOnStateAvailabilityChanged OnStateAvailabilityChanged;

	UPROPERTY(BlueprintAssignable, Category = "Nonlinear System Tools")
		FOnPropertyValueChanged OnPropertyValueChanged;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Story")
		UNSTStoryAsset* Story;
	
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Nonlinear System Tools")
		FString GetSituation();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Nonlinear System Tools")
		int32 GetNumStates();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Nonlinear System Tools")
		int32 GetNumAvailableStates();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Nonlinear System Tools")
		FString GetDialogStatement(FString stateName);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Nonlinear System Tools")
		FString GetStateNameAtIndex(int32 index);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Nonlinear System Tools")
		bool IsStateAvailable(FString stateName);

	UFUNCTION(BlueprintCallable, Category = "Nonlinear System Tools")
		void ActivateState(FString index, bool force);

	UFUNCTION(BlueprintCallable, Category = "Nonlinear System Tools")
		void ResetStory();

	UFUNCTION(BlueprintCallable, Category = "Nonlinear System Tools")
		void SaveStory();

	UFUNCTION(BlueprintCallable, Category = "Nonlinear System Tools")
		FString GetSavedStoryString() { return CurrentStoryString; }

	UFUNCTION(BlueprintCallable, Category = "Nonlinear System Tools")
		void LoadFromString(FString storyString);

	UFUNCTION(BlueprintCallable, Category = "Nonlinear System Tools")
		float GetPropertyValue(FString propertyName);

	UFUNCTION(BlueprintCallable, Category = "Nonlinear System Tools")
		void SetPropertyValue(FString propertyName, float value);

protected:
	virtual void BeginPlay() override;

public:
	virtual void Tick(float DeltaTime) override;

};
