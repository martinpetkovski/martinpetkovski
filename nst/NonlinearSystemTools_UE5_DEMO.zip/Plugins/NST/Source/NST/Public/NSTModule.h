// � 2022 Martin Petkovski. All rights reserved.
#pragma once

#include "Modules/ModuleManager.h"

class FNSTModule : public IModuleInterface
{
public:

	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:
	void* LibraryHandle;
};
