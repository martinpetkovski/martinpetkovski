// � 2022 Martin Petkovski. All rights reserved.
using System;
using System.IO;
using UnrealBuildTool;

public class NSTAPI : ModuleRules
{
    public NSTAPI(ReadOnlyTargetRules Target) : base(Target)
    {
        Type = ModuleType.External;

        PublicIncludePaths.Add(Path.Combine(PluginDirectory, "Source", "ThirdParty"));
        PublicAdditionalLibraries.Add(Path.Combine(PluginDirectory, "Source", "ThirdParty", "NSTAPI.lib"));
        RuntimeDependencies.Add(Path.Combine(PluginDirectory, "Source", "ThirdParty", "NSTAPI.dll"));
        RuntimeDependencies.Add(Path.Combine(PluginDirectory, "Source", "ThirdParty", "NSTGame.dll"));
        RuntimeDependencies.Add(Path.Combine(PluginDirectory, "Source", "ThirdParty", "NSTEngine.dll"));
    }
}