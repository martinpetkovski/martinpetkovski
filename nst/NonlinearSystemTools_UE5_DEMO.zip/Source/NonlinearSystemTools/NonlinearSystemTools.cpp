// � 2022 Martin Petkovski. All rights reserved.
#include "NonlinearSystemTools.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, NonlinearSystemTools, "NonlinearSystemTools" );
