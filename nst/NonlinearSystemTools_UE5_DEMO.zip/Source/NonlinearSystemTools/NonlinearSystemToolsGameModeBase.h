// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "NonlinearSystemToolsGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class NONLINEARSYSTEMTOOLS_API ANonlinearSystemToolsGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
