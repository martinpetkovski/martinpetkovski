// � 2022 Martin Petkovski. All rights reserved.
using UnrealBuildTool;
using System.Collections.Generic;

public class NonlinearSystemToolsEditorTarget : TargetRules
{
	public NonlinearSystemToolsEditorTarget( TargetInfo Target) : base(Target)
	{
		Type = TargetType.Editor;
		DefaultBuildSettings = BuildSettingsVersion.V2;
		ExtraModuleNames.AddRange( new string[] { "NonlinearSystemTools", "NST" } );
	}
}
